import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-KUGRERBS.js";
import "./chunk-7BCGWERV.js";
import "./chunk-AADXTXBF.js";
import "./chunk-BCGYTIL7.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-H2SRQSE4.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
